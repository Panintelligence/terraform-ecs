import logging
import shutil
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    logger.info(event)
    try:
        if os.path.isdir("/mnt/efs/images"):
            shutil.rmtree("/mnt/efs/keys")
            os.makedirs("/mnt/efs/keys")
        if os.path.isdir("/mnt/efs/files"):
            shutil.rmtree("/mnt/efs/keys")
            os.makedirs("/mnt/efs/keys")
        if not os.path.isdir("/mnt/efs/themes") or os.getenv("FORCE_THEMES") == "true":
            shutil.copytree("themes", f"/mnt/efs/themes")
        elif os.getenv("FORCE_THEMES") == "true":
            shutil.rmtree("/mnt/efs/themes")
            shutil.copytree("themes", f"/mnt/efs/themes")
        if os.path.isdir("/mnt/efs/keys"):
            shutil.rmtree("/mnt/efs/keys")
            os.makedirs("/mnt/efs/keys")
        if os.path.isdir("/mnt/efs/svg"):
            shutil.rmtree("/mnt/efs/svg")
            os.makedirs("/mnt/efs/svg")
        if os.path.isdir("/mnt/efs/custom_jdbc"):
            shutil.rmtree("/mnt/efs/custom_jdbc")
            os.makedirs("/mnt/efs/custom_jdbc")
        if os.path.isdir("/mnt/efs/locale"):
            shutil.rmtree("/mnt/efs/locale")
            os.makedirs("/mnt/efs/locale")
    except Exception as e:
        logger.error(e)
        raise e
